#!/usr/bin/python
import sys
import os
import re


  
 #global variables
program = "s25_aa_composition.py"
unix_flag = 0
start_flag = 0


input_fname = "babesia_bovis_prot.fasta"
outputFname = "start_25_aa_composition.txt"


lenRequired = 25
sep = ""
id = ""
seq = ""


#initialise dictionary
dict_seq = {}
dict_counts = {}


list_letters = ["A","R","N","D","C","Q","E","G","H","I","L","K","M","F","P","S","T","W","Y","V"]

#alanine - ala - A
#arginine - arg - R
#asparagine - asn - N
#aspartic acid - asp - D
#cysteine - cys - C
#glutamine - gln - Q
#glutamic acid - glu - E
#glycine - gly - G
#histidine - his - H
#isoleucine - ile - I
#leucine - leu - L
#lysine - lys - K
#methionine - met - M
#phenylalanine - phe - F
#proline - pro - P
#serine - ser - S
#threonine - thr - T
#tryptophan - trp - W
#tyrosine - tyr - Y
#valine - val - V 

   
##### Main

#check for windows or unix
if os.name == 'nt':
   print ("Windows version\n")
   sep = "/"
else:
   print ("Unix version\n")
   sep = "\\"
   
	
#Open a log file
#log_file = open("log.txt", "w")

# Program starting message:
print ("\nStarting Program ",program, "\n")
print ("\n PLEASE WAIT .....\n\n")
  

fileOut = open(outputFname, "w")
	  
	  
with open(input_fname, "r") as line: 
   for line_input in line:
	
      #trim leading and trailing white spaces
      line_input = line_input.strip()
	  
      if line_input.startswith(">"):
	  
        if start_flag == 1:
		
         seqLength = len (seq)
          		 
         #Get first 25 aa
         if seqLength >= 25:
            seq = seq [:lenRequired]
            dict_seq [id] = seq
            #fileOut.write (seq + "\n")
         else:
            print (">> Sequence " + id + " too short")
         
         seq = ""          
        
        #>BBOV_III005790  | Babesia bovis T2Bo | Spherical Body Protein 2 truncated copy 3 (SBP2) | protein  | length=242	 
        #slit using |
        list = line_input.split ("|",line_input.count("|"))
	  
        id = list [0].strip ()
        id = id [1:]
        print (id)
        start_flag = 1

      else:
         seq = seq + line_input	

#last protein
if start_flag == 1:
   seqLength = len (seq)
          		 
   #Get first 25 aa
   if seqLength >= 25:
      seq = seq [:lenRequired]
      dict_seq [id] = seq
      #fileOut.write (seq + "\n")
   
header = "ID"
for first_letter in list_letters:
   for second_letter in list_letters:
      header = header + "\tS" + first_letter + second_letter

fileOut.write (header + "\n") 

for id,seq in dict_seq.items ():

   fileOut.write (id + "\t")
   
   for first_letter in list_letters:
      for second_letter in list_letters:
	  
         combinedLetters = first_letter + second_letter
         letterCount = seq.count (combinedLetters)
         fileOut.write (str (letterCount) + "\t")

         if combinedLetters in dict_counts:
            dict_counts [combinedLetters] = dict_counts [combinedLetters] + letterCount
         else:
            dict_counts [combinedLetters] = letterCount
		 
   fileOut.write ("\n")
  
   
		
# Program finishing message:
print ("\nFinished program",program, "Successfully \n")








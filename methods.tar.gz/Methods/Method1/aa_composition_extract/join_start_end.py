#!/usr/bin/python
import sys
import os
import re


  
 #global variables
program = "join_start_end.py"
unix_flag = 0
header_start = ""
header_end = ""
prefix = "BBOV"

start_fname = "start_25_aa_composition.txt"
end_fname = "end_25_aa_composition.txt"


output_file = "T2Bo_aa_composition"



#initialise dictionary
dict_start = {}
dict_end = {}

#Delete element from list
def return_string (list,elementNo,sep):

   retString = ""
   startFlag = 0
   
   #delete element from list
   del(list[elementNo])
   
   for element in list:
   
      if startFlag == 0:
         retString = element
         startFlag = 1
      else:
         retString = retString + sep + element

   return retString	



   
##### Main

#check for windows or unix
sep = ""
if os.name == 'nt':
   print ("Windows version\n")
   sep = "/"
else:
   print ("Unix version\n")
   sep = "\\"
   
	
#Open a log file
#log_file = open("log.txt", "w")

# Program starting message:
print ("\nStarting Program ",program, "\n")
print ("\n PLEASE WAIT .....\n\n")
  

fileOut = open(output_file, "w")
	  
#open start file	  
with open(start_fname, "r") as line: 
   for line_input in line:
	
      #trim leading and trailing white spaces
      line_input = line_input.strip()
	  
      #split using tab delimited
      list = re.split(r'\t', line_input)

      id = list[0].strip ()

      line_input = line_input.replace ("\t",",")

      if id == "ID":
         header_start = line_input
      elif id.startswith (prefix):	  
         dict_start [id] = line_input 
      
#open end file	  
with open(end_fname, "r") as line: 
   for line_input in line:
	
      #trim leading and trailing white spaces
      line_input = line_input.strip()
	  
      #split using tab delimited
      list = re.split(r'\t', line_input)

      line_input = line_input.replace ("\t",",")

      id = list[0].strip ()

      #remove ID	  
      line_input = return_string (list,0,",")

      if id == "ID":
         header_end = line_input
      elif id.startswith (prefix):
         dict_end [id] = line_input


#print out header
fileOut.write (header_start + "," + header_end + ",Candidate\n")
	  
	  
for id,start_line_input in dict_start.items ():

   print (id)
   end_line_input = dict_end [id]

   fileOut.write (start_line_input + "," + end_line_input + "\n")
	  

		
# Program finishing message:
print ("\nFinished program",program, "Successfully \n")








#!/usr/bin/python
import sys
import os
import re


#global variables
program = "select.py"

required_fname = "positives"
output_fname = "train_pos"


#initialise dictionary
dict_required = {}

#Open required file
with open(required_fname, "r") as line:

   for line_input in line:
 	
      #trim leading and trailing white spaces
      line_input = line_input.strip()
	  
      dict_required [line_input] = 1

# Program starting message: 
print ("Starting Program",program)
print ("\n PLEASE WAIT .....\n\n")

#Open a file to write
fileOut = open(output_fname, "w")
#fileLog = open("log_file.txt", "w")

startFlag = 0

#get current directory
wd = os.getcwd()


print ('Current working directory:',wd)

#Get files in prediction directory
files = os.listdir(wd)

#process all files in predictions directory
for file in files:

   fileNo = 0

   if file.endswith ("position"):
      print (file)


      #Openinput file
      with open(file, "r") as line:

         for line_input in line:
 	
            #trim leading and trailing white spaces
            line_input = line_input.strip()
	  
 	    #BBOV_I004490,0,-2,3
            if line_input.startswith ("BBOV_"):
	        			
               list = line_input.split (",",line_input.count(","))
               id = list[0].strip ()
  
               if id  in dict_required:
                   fileOut.write (line_input + "\n")	
                  

            elif line_input.startswith ("ID"):
               fileOut.write (line_input + "\n")		   
		 
	  
print ("\nFinished program",program, "Successfully \n")   






### Function calls

nn_runPred <- function (no_of_repeats,output_file)
{
		
		cat("Running nn_runPred\n")

		require(nnet, quietly=TRUE)
			
		sink(file = output_file)
	
		increment <- 1
		while( increment <= no_of_repeats) { 

			out <- nn_makePred ()
			
			cat("Run:",increment,"\n")
	
			print (out)
			
			increment <- increment + 1
		}
		
		sink ()

}

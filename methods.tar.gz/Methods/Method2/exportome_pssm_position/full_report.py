#!/usr/bin/python
import sys
import os
import re


  
 #global variables
program = "full_report.py"
unix_flag = 0
start_flag = 0


positive_fname = "positives.fa"
negative_fname = "random_negatives.fa" 
input_fname = "vaccine_candidates"

outputFname = "ML_exportome_full_report.txt"

'''
 Accuracy (ACC) = (TP+TN)/(TP+FP+FN+TN) - how often the classifier is correct; 
 Misclassification or Error Rate = (FP+FN)/(TP+FP+FN+TN)  - how often the classifier is incorrect; 
 True Positive Rate (TPR) or Sensitivity (SN) = TP/(TP + FN) -when the condition is positive, how often the classifier correctly predicts a positive condition;
 False Positive Rate (FPR) = FP/(FP + TN) - when the condition is negative, how often the classifier incorrectly predicts a positive condition; 
 True Negative Rate (TNR) or Specificity (SP) = TN/(TN + FP) - when the condition is negative, how often the classifier correctly predicts a negative condition; 
 Precision or Positive Predictive Value (PPV)= TP/(TP + FP) - when the classifier predicts a positive condition, how often is the prediction correct; 
 Prevalence = (TP + FN)/ (TP+FP+FN+TN) - how often the positive condition occurs in the sample. 

'''


sep = ""
id = ""
required_index = 5
threshold = 0.5

#stats
tp = 0
tn = 0
fp = 0
fn = 0


#initialise dictionary
dict_train = {}

   
##### Main

#check for windows or unix
if os.name == 'nt':
   print ("Windows version\n")
   sep = "\\"
else:
   print ("Unix version\n")
   sep = "/"
   
	
#Open a log file
#log_file = open("log.txt", "w")

# Program starting message:
print ("\nStarting Program ",program, "\n")
print ("\n PLEASE WAIT .....\n\n")
 
input_dir = sys.argv[1] 

fileOut = open(outputFname, "w")


with open(positive_fname, "r") as line: 
   for line_input in line:
	
      #trim leading and trailing white spaces
      line_input = line_input.strip()
	  
      if line_input.startswith(">"):
   
         list = line_input.split ("|",line_input.count("|"))
	  
         id = list [0].strip ()
         id = id [1:]
 	  
         dict_train [id] = 1
		 
		 
with open(negative_fname, "r") as line: 
   for line_input in line:
	
      #trim leading and trailing white spaces
      line_input = line_input.strip()
	  
      if line_input.startswith(">"):
   
         list = line_input.split ("|",line_input.count("|"))
	  
         id = list [0].strip ()
         id = id [1:]
 	  
         dict_train [id] = 0		 
		 
	  
	  
with open(input_dir + sep + input_fname, "r") as line: 
   for line_input in line:
	
      #trim leading and trailing white spaces
      line_input = line_input.strip()
	  
      if line_input.startswith("#ID"):
         continue

      else:
         #ID,ada,knn,nb,nn,rf,svm,average_ML_score
      		 

         list = line_input.split (",",line_input.count(","))
	  
         id = list [0].strip ()
		 
         score = list [required_index].strip ()
         score = float (score)
		 
         true_value = 99
         if id in dict_train:
            true_value = dict_train [id]
			
			
            #true positive
            if ((true_value == 1) and (score >= threshold)):
               #fileOut.write (id + "\t" + str (score) + "\t" + str(true_value) + "\n")
               tp += 1
            #true negative			   
            elif ((true_value == 0) and (score < threshold)):
               #fileOut.write (id + "\t" + str (score) + "\t" + str(true_value) + "\n")
               tn += 1
            #false positive			   
            elif ((true_value == 0) and (score >= threshold)):
               #fileOut.write (id + "\t" + str (score) + "\t" + str(true_value) + "\n")
               fp += 1
            #false negative			   
            elif ((true_value == 1) and (score < threshold)):
               #fileOut.write (id + "\t" + str (score) + "\t" + str(true_value) + "\n")
               fn += 1				   
			
         else:
            print (id + " not found!!")
			
			
print (tp)
print (tn)
print (fp)
print (fn)
                 
fileOut.write ("# Accuracy (ACC) = (TP+TN)/(TP+FP+FN+TN) - how often the classifier is correct\n")
result = (tp + tn) / float(tp + fp + fn + tn)
result = result * 100
result = round (result,2)

fileOut.write (str (result) + "%\n")

fileOut.write ("\n# Misclassification or Error Rate = (FP+FN)/(TP+FP+FN+TN) - how often the classifier is incorrect\n")
result = (fp + fn) / float(tp + fp + fn + tn)
result = result * 100
result = round (result,2)

fileOut.write (str (result) + "%\n")

fileOut.write ("\n# True Positive Rate (TPR) or Sensitivity (SN) = TP/(TP + FN) - when the condition is positive, how often the classifier correctly predicts a positive condition\n")
result = tp / float (tp + fn)
result = result * 100
result = round (result,2)

fileOut.write (str (result) + "%\n")

fileOut.write ("\n# False Positive Rate (FPR) = FP/(FP + TN) - when the condition is negative, how often the classifier incorrectly predicts a positive condition\n")
result = fp / float(fp + tn)
result = result * 100
result = round (result,2)

fileOut.write (str (result) + "%\n")

fileOut.write ("\n# True Negative Rate (TNR) or Specificity (SP) = TN/(TN + FP) - when the condition is negative, how often the classifier correctly predicts a negative condition\n")
result = tn / float (tn + fp)
result = result * 100
result = round (result,2)

fileOut.write (str (result) + "%\n")

fileOut.write ("\n# Precision or Positive Predictive Value (PPV)= TP/(TP + FP) - when the classifier predicts a positive condition, how often is the prediction correct\n")

result = tp / float(tp + fp)
result = result * 100
result = round (result,2)

fileOut.write (str (result) + "%\n")

fileOut.write ("\n# Negative Predictive Value (NPV)= TN/(TN + FN) - when the classifier predicts a negative condition, how often is the prediction correct\n")

result = tn / float (tn + fn)
result = result * 100
result = round (result,2)

fileOut.write (str (result) + "%\n")

 
fileOut.write ("\n# Prevalence = (TP + FN)/ (TP+FP+FN+TN) - how often the positive condition occurs in the sample\n")
result = (tp + fn) / float (tp + fp + fn + tn)
result = result * 100
result = round (result,2)

fileOut.write (str (result) + "%\n")
 			
 	  
		
# Program finishing message:
print ("\nFinished program",program, "Successfully \n")








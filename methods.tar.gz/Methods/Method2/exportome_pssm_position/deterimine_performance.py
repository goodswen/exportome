#!/usr/bin/python
import sys
import os
import re


  
 #global variables
program = "determine_perfornance.py"
unix_flag = 0
start_flag = 0


positive_fname = "positives.fa"
negative_fname = "random_negatives.fa" 
input_fname = "vaccine_candidates"

outputFname = "Stats_for_ML_exportome.txt"

'''
 Accuracy (ACC) = (TP+TN)/(TP+FP+FN+TN) - how often the classifier is correct; 
 Misclassification or Error Rate = (FP+FN)/(TP+FP+FN+TN)  - how often the classifier is incorrect; 
 True Positive Rate (TPR) or Sensitivity (SN) = TP/(TP + FN) -when the condition is positive, how often the classifier correctly predicts a positive condition;
 False Positive Rate (FPR) = FP/(FP + TN) - when the condition is negative, how often the classifier incorrectly predicts a positive condition; 
 True Negative Rate (TNR) or Specificity (SP) = TN/(TN + FP) - when the condition is negative, how often the classifier correctly predicts a negative condition; 
 Precision or Positive Predictive Value (PPV)= TP/(TP + FP) - when the classifier predicts a positive condition, how often is the prediction correct; 
 Prevalence = (TP + FN)/ (TP+FP+FN+TN) - how often the positive condition occurs in the sample. 

'''


sep = ""
id = ""

threshold = 0.5
algorithmCount = 0

header = "Algorithm,Accuracy,Error Rate,Sensitivity,False Positive Rate,Specificity,Positive Predictive Value,Negative Predictive Value, Prevalence" 

#for loop (incremental)
start = 1
end = 6
step = 1

#initialise dictionary
dict_train = {}
dict_candidates = {}
dict_algorithm = {}

   
##### Main

#check for windows or unix
if os.name == 'nt':
   print ("Windows version\n")
   sep = "\\"
else:
   print ("Unix version\n")
   sep = "/"
   
	
#Open a log file
#log_file = open("log.txt", "w")

# Program starting message:
print ("\nStarting Program ",program, "\n")
print ("\n PLEASE WAIT .....\n\n")
  
input_dir = sys.argv[1] 

fileOut = open(outputFname, "w")

fileOut.write(header + "\n")


with open(positive_fname, "r") as line: 
   for line_input in line:
	
      #trim leading and trailing white spaces
      line_input = line_input.strip()
	  
      if line_input.startswith(">"):
   
         list = line_input.split ("|",line_input.count("|"))
	  
         id = list [0].strip ()
         id = id [1:]
 	  
         dict_train [id] = 1
		 
		 
with open(negative_fname, "r") as line: 
   for line_input in line:
	
      #trim leading and trailing white spaces
      line_input = line_input.strip()
	  
      if line_input.startswith(">"):
   
         list = line_input.split ("|",line_input.count("|"))
	  
         id = list [0].strip ()
         id = id [1:]
 	  
         dict_train [id] = 0		 
		 
	  
#read the candidates	  
with open(input_dir + sep + input_fname, "r") as line: 
   for line_input in line:
	
      #trim leading and trailing white spaces
      line_input = line_input.strip()
	  
      if line_input.startswith("#ID"):
         list = line_input.split (",",line_input.count(","))
		 
         for algorithm in list:
            if algorithm == "#ID":
               continue
            else:
               algorithmCount += 1
               dict_algorithm [algorithmCount] = algorithm

      else:
         #ID,ada,knn,nb,nn,rf,svm,average_ML_score
      		 

         list = line_input.split (",",line_input.count(","))
	  
         id = list [0].strip ()
		 
         dict_candidates [id] = line_input
 

#loop for each algorithm 
for required_index in range(start, end, step):

   #stats
   tp = 0
   tn = 0
   fp = 0
   fn = 0

   for id,line_input in dict_candidates.items ():

      
			
      list = line_input.split (",",line_input.count(","))
		 
      score = list [required_index].strip ()
      score = float (score)
		 
      true_value = 99
      if id in dict_train:
         true_value = dict_train [id]
			
         #true positive
         if ((true_value == 1) and (score >= threshold)):
            #fileOut.write (id + "\t" + str (score) + "\t" + str(true_value) + "\n")
            tp += 1
         #true negative			   
         elif ((true_value == 0) and (score < threshold)):
            #fileOut.write (id + "\t" + str (score) + "\t" + str(true_value) + "\n")
            tn += 1
         #false positive			   
         elif ((true_value == 0) and (score >= threshold)):
            #fileOut.write (id + "\t" + str (score) + "\t" + str(true_value) + "\n")
            fp += 1
         #false negative			   
         elif ((true_value == 1) and (score < threshold)):
            #fileOut.write (id + "\t" + str (score) + "\t" + str(true_value) + "\n")
            fn += 1				   

      else:
         print (id + " not found!!")
			
			
   print (tp)
   print (tn)
   print (fp)
   print (fn)
   
   #Get algorithm
   algorithm = dict_algorithm [required_index]
   fileOut.write (algorithm)   
   
                 
   # Accuracy (ACC) = (TP+TN)/(TP+FP+FN+TN) - how often the classifier is correct
   result = (tp + tn) / float (tp + fp + fn + tn)
   result = result * 100
   result = round (result,2)
   fileOut.write ("," + str (result))

   # Misclassification or Error Rate = (FP+FN)/(TP+FP+FN+TN) - how often the classifier is incorrect
   result = (fp + fn) / float (tp + fp + fn + tn)
   result = result * 100
   result = round (result,2)
   fileOut.write ("," + str (result))


   # True Positive Rate (TPR) or Sensitivity (SN) = TP/(TP + FN) - when the condition is positive, how often the classifier correctly predicts a positive condition
   result = tp / float (tp + fn)
   result = result * 100
   result = round (result,2)
   fileOut.write ("," + str (result))

   # False Positive Rate (FPR) = FP/(FP + TN) - when the condition is negative, how often the classifier incorrectly predicts a positive condition
   result = fp / float (fp + tn)
   result = result * 100
   result = round (result,2)
   fileOut.write ("," + str (result))


   # True Negative Rate (TNR) or Specificity (SP) = TN/(TN + FP) - when the condition is negative, how often the classifier correctly predicts a negative condition
   result = tn / float (tn + fp)
   result = result * 100
   result = round (result,2)
   fileOut.write ("," + str (result))

   # Precision or Positive Predictive Value (PPV)= TP/(TP + FP) - when the classifier predicts a positive condition, how often is the prediction correct
   result = tp / float(tp + fp)
   result = result * 100
   result = round (result,2)
   fileOut.write ("," + str (result))
   
   # Negative Predictive Value (NPV)= TN/(TN + FN) - when the classifier predicts a negative condition, how often is the prediction correct
   result = tn / float(tn + fn)
   result = result * 100
   result = round (result,2)
   fileOut.write ("," + str (result))

   # Prevalence = (TP + FN)/ (TP+FP+FN+TN) - how often the positive condition occurs in the sample\n")
   result = (tp + fn) / float(tp + fp + fn + tn)
   result = result * 100
   result = round (result,2)
   fileOut.write ("," + str (result))

   fileOut.write ("\n")
 			
	  
		
# Program finishing message:
print ("\nFinished program",program, "Successfully \n")








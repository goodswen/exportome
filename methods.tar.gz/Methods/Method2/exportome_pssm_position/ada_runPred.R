### Function calls

ada_runPred <- function (no_of_repeats,output_file)
{
		
		cat("Running ada_runPred\n")

		require(ada, quietly=TRUE)
			
		sink(file = output_file)
			
		increment <- 1
		while( increment <= no_of_repeats) { 

			out <- ada_makePred ()
			
			cat("Run:",increment,"\n")
	
			print (out)
			
			increment <- increment + 1
		}
		
		sink ()
}

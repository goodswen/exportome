### Function calls

svm_runPred  <- function (no_of_repeats,output_file)
{
		
		cat("Running svm_runPred\n")
		
		library (kernlab)
		sink(file = output_file)

		increment <- 1
		while( increment <= no_of_repeats) { 

			out <- svm_makePred ()
			
			cat("Run:",increment,"\n")
	
			print (out)
			
			increment <- increment + 1
		}
		
		sink ()

}

#!/usr/bin/python
import sys
import os
import re


  
 #global variables
program = "position_pssm_extract.py"
unix_flag = 0
start_flag = 0
required_length = 25

#input_fname = "psiblast_bov_1234.txt"

outputFname = "T2Bo_pssm_position"

filePrefix = "psiblast"
status = "Y"

sep = ""

#protien dictionary
dict_prot = {
         "1":"A","2":"R","3":"N","4":"D","5":"C","6":"Q","7":"E","8":"G","9":"H",
		 "10":"I","11":"L","12":"K","13":"M","14":"F","15":"P","16":"S","17":"T","18":"W","19":"Y","20":"V"
}
  
   
##### Main

#check for windows or unix
if os.name == 'nt':
   print ("Windows version\n")
   sep = "/"
else:
   print ("Unix version\n")
   sep = "\\"
   
	
#Open a log file
#log_file = open("log.txt", "w")

# Program starting message:
print ("\nStarting Program ",program, "\n")
print ("\n PLEASE WAIT .....\n\n")
  

fileOut = open(outputFname, "w")


#get current directory
wd = os.getcwd()

print ('Current working directory:',wd)

#Get files in working directory
files = os.listdir(wd)


#list all files in current directory
for file in files:

   if file.startswith (filePrefix):
      
      #initialise dictionary and list
      dict_letters = {}
      list_input = []
      list_trimmed_input = []
      dict_ml = {}
      dict_num_map = {}
      no_of_proteins = 0
      posCount = 75 # this for the end positions	  
	  
      print (file)
	  
	  #extract ID from filename
      prefix_len = len (filePrefix) + 1
      id = file [prefix_len:]
      id = id.strip ()
      print (id)
	  
      with open(file, "r") as line: 
         for line_input in line:
	
            #trim leading and trailing white spaces
            line_input = line_input.strip()
	  
            if line_input.startswith("Last"):
               continue

            #check for empty line
            elif not line_input:
               continue

	        #check for protein letters
            elif line_input.startswith("A"):
         
               list = re.split(r'\s+', line_input)
		 
               for letter in list:
                  dict_letters[letter] = 0		 
		 

            elif line_input[0].isdigit():
 
               no_of_proteins += 1
		 
               list_input.append (line_input)
 

      end_number =  no_of_proteins - required_length + 1
	  
      #initial start ml dictionary
      for num in range(1, required_length + 1, 1):
         dict_num_map [num] = num
         for firstKey,firstLetter in sorted(dict_prot.items ()):
            dict_ml ["P" + str(num) + firstLetter] = 0

      #initial end ml dictionary
      for num in range(end_number, no_of_proteins + 1, 1):
         posCount +=1
         dict_num_map [num] = posCount
         for firstKey,firstLetter in sorted(dict_prot.items ()):
            dict_ml ["P" + str(posCount) + firstLetter] = 0


      #for key, value in dict_num_map.items ():
         #print (str(key) + "\t" + str (value))	 
            

      #remove unwanted values
      for line in list_input:

         list = re.split(r'\s+', line)
	  
         number = int (list [0].strip ())
   
         if ((number <= required_length) or (number >= end_number)):

            count = 0
            trimmed_line = ""
            
            for value in list:
	  
               value = value.strip ()
               if (count == 0):
                  trimmed_line = value
               elif (count < 22):
                  trimmed_line = trimmed_line + "\t" + value
            
               count += 1
     
            list_trimmed_input.append (trimmed_line)

    
      for line in list_trimmed_input:
 
         list = re.split(r'\t', line)
		 
		 #get the number from the input file
         number = list [0].strip ()
		 
         number = dict_num_map [int (number)]

         count = 0
         for value in list:

            if (count > 1):
               value = int( value.strip ())
			
               #get the position number and column_letter
               index = count - 1
               index = str(index)
               column_letter = dict_prot [index]
               predictor = "P" + str(number) + column_letter

               dict_ml [predictor] = dict_ml [predictor] + value
         
            count += 1           			

      header_line = ""
      value_line = ""			
      for predictor, value in sorted (dict_ml.items ()):

         if header_line == "":
            header_line = "ID" + "," + predictor 
         else:
            header_line = header_line + "," + predictor   
 			  
         if value_line == "":
            value_line = str(id) + "," + str(value) 
         else:
            value_line = value_line + "," + str(value)      
   
      #print out results
      if start_flag == 0:
         fileOut.write (header_line + ",Candidate\n")
         start_flag = 1
      fileOut.write (value_line + "," + status + "\n") 
		
# Program finishing message:
print ("\nFinished program",program, "Successfully \n")







